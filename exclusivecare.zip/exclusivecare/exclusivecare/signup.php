<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Exclusive Care</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">

    <body>

    <div class="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                <label>E X C L U S I V E C A R E</label>
            </div>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="pre-order.php">Pre-Order</a></li>
                    <li><a href="product.html">Product</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="account.html">Account</a></li>
                </ul>
            </nav>
            <i class="fad fa-shopping-bag"></i>
        </div>

<form>
    <span class="border border-info">
    <div class="container-fluid">
    <div class="float-md-left">
    <div class="jumbotron">
        <div class="container-fluid">
            <h4 style="font-family:Verdana, Geneva, Tahoma, sans-serif;">Sign up</h4>
            </div>
        <div class="container mt-1">
            <div class="contact-box">
                <div class="left"></div>
                <div class="right">
            </div>
    <div class="form-group row mt-4">
    <div class="col-sm-10">
    <label for="username">Nama:</label><sbr>
    <input type="text" id="username" name="username"><br>

    <div class="form-group row mt-4">
    <div class="col-sm-10">
    <label for="pwd">Password:</label><ssbr>
    <input type="password" id="pwd" name="pwd">
    <input type="password" id="pwd" name="pwd">

    <div class="form-group row mt-4">
    <div class="col-sm-10">
    <div class="container-fluid">
        <a href="account.html" class="">have a user? Sign in</a>
    
    <div class="form-group row mt-4">
        <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Sign up</button>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
</span>
</form>
</html>