<?php
function http_request($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}
$data = http_request("http://localhost/exclusivecare/api/api_edit.php?id=");
$data = json_decode($data, TRUE);
?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">

    <body>

    <div class="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                <label>E X C L U S I V E C A R E</label>
            </div>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="pre-order.php">Pre-Order</a></li>
                    <li><a href="product.html">Product</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="account.html">Account</a></li>
                </ul>
            </nav>
        </div>
    </div>    


                <div class="content">
                <div class="alert alert-secondary" role="alert">
                    <div class="container pt-4">
                    <p> <a href="../exclusivecare/pre-order.php">Back</a> </p>
                    <div class="container w-100 bg-info text-light rounded">
	                    <form class="form-container p-5" action="http://localhost/exclusivecare/api/api_edit.php" method="POST" id="form">
		                <div>
                        <h3 class="text-light text-center"><b>Edit Data Pre-Order</b></h3>
		                <hr class="bg-light">
		                    <div class="form-group">
                                <label for="">nomor</label>
                                <input type="text" class="form-control" value="<?= $data["id"] ?>" name="id" id="id" placeholder="id"> 
                            </div>
                            <div class="form-group">
                                <label for="">Nama</label>
                                <input type="text" class="form-control" value="<?= $data["nama"] ?>" name="nama" id="nama" placeholder="Nama">
                             </div>
                            <div class="form-group">
                                <label for="">Merek</label>
                                <input type="text" class="form-control" value="<?= $data["Merek"] ?>" name="Merek" id="Merek" placeholder="Merek"> 
                            </div>
                            <div class="form-group">
                                <label for="">Produk</label>
                                <input type="text" class="form-control" value="<?= $data["Produk"] ?>" name="Produk" id="Produk" placeholder="Produk"> 
                            </div>
                            <div class="form-group">
                                <label for="">Hp</label>
                                <input type="text" class="form-control" value="<?= $data["Hp"] ?>" name="Hp" id="Hp" placeholder="Hp"> 
                            </div>
                            <div class="form-group">
                                <label for="">Email</label>
                                <input type="text" class="form-control" value="<?= $data["Email"] ?>" name="Email" id="Email" placeholder="Email"> 
                            </div>
                            <div class="form-group">
                                <label for="">Alamat</label>
                                <input type="text" class="form-control" value="<?= $data["Alamat"] ?>" name="Alamat" id="Alamat" placeholder="Alamat"> 
                            </div>
                            <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-outline-warning btn-lg btn-block">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            </div>
            <div class="clear"></div>
            <div class="footer">
                <p> En & Jun @ copyright 2021</p>
            </div>
        </div>
        </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    </body>
</html>
    